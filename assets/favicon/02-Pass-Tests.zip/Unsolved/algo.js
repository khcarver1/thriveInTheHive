function Algo() {}

Algo.prototype.reverse = function(str) {
  // TODO: Your code here
  // TODO: convert string to an array
  // TODO: reverse substrings in array
  // TODO: convert array back into a string
};

Algo.prototype.isPalindrome = function(str) {
  // TODO: Your code here
};

Algo.prototype.capitalize = function(str) {
  // TODO: Your code here
};

module.exports = Algo;
